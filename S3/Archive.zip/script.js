// Scroll Reveal Animation
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('active');
            // Once animated, stop observing
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe all elements with 'reveal' class
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// Smooth Scrolling for Nav Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            const headerOffset = 80;
            const elementPosition = targetElement.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// Mobile Menu Toggle (Minimal implementation)
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', () => {
        // This would be expanded for a more robust mobile nav
        console.log('Mobile menu clicked');
    });
}

// Particle/Data Animation in Hexagon (Visual Polish)
function createDataParticle() {
    const visual = document.querySelector('.s3-bucket-visual');
    if (!visual) return;

    const particle = document.createElement('div');
    particle.className = 'data-particles';
    
    // Random position
    const x = Math.random() * 80 + 10;
    const y = Math.random() * 80 + 10;
    
    particle.style.left = `${x}%`;
    particle.style.top = `${y}%`;
    particle.style.position = 'absolute';
    particle.style.width = '4px';
    particle.style.height = '4px';
    particle.style.background = 'var(--primary)';
    particle.style.borderRadius = '50%';
    particle.style.opacity = '0';
    particle.style.transition = 'all 1s ease-out';
    
    visual.appendChild(particle);
    
    // Animate
    setTimeout(() => {
        particle.style.opacity = '0.6';
        particle.style.transform = 'translateY(-20px)';
    }, 10);
    
    setTimeout(() => {
        particle.remove();
    }, 1000);
}

// Periodically create particles
setInterval(createDataParticle, 500);

// Header transparency on scroll
window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
        header.style.background = 'rgba(10, 14, 20, 0.95)';
        header.style.padding = '0.5rem 0';
    } else {
        header.style.background = 'rgba(10, 14, 20, 0.8)';
        header.style.padding = '1rem 0';
    }
});
